# UiTMSlides
UiTMSlides is a LaTeX Beamer style for UiTM presentation slides.
The slides is based on the UiTM Slide Master template from https://korporat.uitm.edu.my/index.php/download/brand-management.
